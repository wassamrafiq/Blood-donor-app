import 'package:blood_donor_application/search.dart';
import 'package:blood_donor_application/login.dart';
import 'package:blood_donor_application/signin.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
    child: Column(
      children:[
        Container(
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 248, 7, 7),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20)
            )
          ),
          height: 320,
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Image.asset("images/blood_2.png"),
          ),
        ),
        SizedBox(
          height: 120,
        ),
        Loginbutton("Blood Donor",context),
        SizedBox(
          height: 10,
        ),
        Loginbutton("Blood Receiver",context),
        SizedBox(
          height: 5,
        ),
        //Text("Learn more", style: TextStyle(fontSize: 15)),
      ],
    ),
  );
  }
}
Widget Loginbutton(String choice,BuildContext context){
  return Padding(
       padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          height: 50,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 245, 25, 10),
            borderRadius: BorderRadius.all(Radius.circular(20))),
          child: TextButton(
            onPressed: (){
              if(choice == "Blood Donor")
              {
                //print("Title     =${title}");
                //Navigator.of(context as BuildContext).pushNamed('/signin');
                //title = "${title}"
                Navigator.push(
                        context ,
                        MaterialPageRoute(builder: (context) => Login()));
              }
              else
              if(choice == "Blood Receiver")
              {
                //print("Title     =${title}");
                Navigator.push(
                        context ,
                        MaterialPageRoute(builder: (context) => Search()));
              }
            }, 
            child: Text(choice, 
              style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold)))),
    );
}
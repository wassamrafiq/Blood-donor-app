import 'dart:js';
import 'package:blood_donor_application/splash.dart';
import 'package:blood_donor_application/signin.dart';
import 'package:blood_donor_application/signup.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: content(context),
    );
  }
}

Widget content(BuildContext context){
  return SingleChildScrollView(
    child: Column(
      children:[
        Container(
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 248, 7, 7),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20)
            )
          ),
          height: 320,
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Image.asset("images/blood_2.png"),
          ),
        ),
        SizedBox(
          height: 120,
        ),
        Loginbutton("Sign in",context),
        SizedBox(
          height: 10,
        ),
        Loginbutton("Create Account",context),
        SizedBox(
          height: 5,
        ),
        //Text("Learn more", style: TextStyle(fontSize: 15)),
      ],
    ),
  );
}

Widget Loginbutton(String title,BuildContext context){
  return Padding(
       padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Container(
          height: 50,
          width: double.infinity,
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 245, 25, 10),
            borderRadius: BorderRadius.all(Radius.circular(20))),
          child: TextButton(
            onPressed: (){
              if(title == "Sign in")
              {
                //print("Title     =${title}");
                //Navigator.of(context as BuildContext).pushNamed('/signin');
                //title = "${title}";
                Navigator.push(
                        context ,
                        MaterialPageRoute(builder: (context) => Signin()));
              }
              else
              if(title == "Create Account")
              {
                //print("Title     =${title}");
                Navigator.push(
                        context ,
                        MaterialPageRoute(builder: (context) => Signup()));
              }
            }, 
            child: Text(title, 
              style: TextStyle(fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold)))),
    );
}
import 'package:blood_donor_application/donorprofile.dart';
import 'package:blood_donor_application/sidedrawer.dart';
import 'package:blood_donor_application/signin.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firestorehelper.dart';
import 'search.dart';
import 'bloodDonorActivity.dart';

class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  TextEditingController nameController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  String? _selectedCity;
  String? _selectedBloodGroup;

  final _formKey = GlobalKey<FormState>();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;

  Future<void> registerUser() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: emailController.text,
          password: passwordController.text,
        );

        String userId = userCredential.user!.uid;
        BloodDonor donor = BloodDonor(
          nameController.text,
          int.parse(ageController.text),
          mobileController.text,
          _selectedCity!,
          _selectedBloodGroup!,
          emailController.text.toString(),
        );

        FirestoreHelper firestoreHelper = await FirestoreHelper.getInstance();
        await firestoreHelper.saveBloodDonor(donor);

        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('userId', userId);
        await prefs.setString('userName', nameController.text);
        await prefs.setString('userEmail', emailController.text);
        SharedPreferences sharedPref = await SharedPreferences.getInstance();
        await sharedPref.setBool("KEYLOGIN", true);

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => DonorProfile()),
        );
      } on FirebaseAuthException catch (e) {
        if (e.code == 'weak-password') {
          popup("The provided password is too weak!", 14);
        } else if (e.code == 'email-already-in-use') {
          popup("An account with this email already exists!", 14);
        } else {
          popup("Error: ${e.message}", 14);
        }
      } catch (e) {
        popup("Error: ${e.toString()}", 14);
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void popup(String txt, double size) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Color(0xFFE50914), // Netflix red
        content: Row(
          children: [
            Icon(
              Icons.warning,
              color: Colors.white,
            ),
            SizedBox(width: 8), // Add spacing between icon and text
            Text(
              txt,
              style: TextStyle(fontSize: size, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    height: 200,
                    child: Image.asset("images/blood_3.png", fit: BoxFit.fill),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                  ),
                  SizedBox(height: 10),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 235, 4, 4),
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          SizedBox(height: 20),
                          nameTextField(),
                          SizedBox(height: 12),
                          emailTextField(),
                          SizedBox(height: 12),
                          passwordTextField(),
                          SizedBox(height: 12),
                          ageTextField(),
                          SizedBox(height: 12),
                          mobileTextField(),
                          SizedBox(height: 12),
                          cityDropDown(),
                          SizedBox(height: 12),
                          bloodGroupDropDown(),
                          SizedBox(height: 20),
                          getButton(context),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
      drawer: SideDrawer(),
    );
  }

  Widget nameTextField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: TextFormField(
        controller: nameController,
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          hintText: "Name",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your name';
          }
          return null;
        },
      ),
    );
  }

  Widget emailTextField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: TextFormField(
        controller: emailController,
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          hintText: "Email",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your email';
          }
          return null;
        },
      ),
    );
  }

  Widget passwordTextField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: TextFormField(
        controller: passwordController,
        textAlign: TextAlign.center,
        obscureText: true,
        decoration: InputDecoration(
          hintText: "Password",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter your password';
          }
          return null;
        },
      ),
    );
  }

 Widget ageTextField() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: TextFormField(
      controller: ageController,
      textAlign: TextAlign.center,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        hintText: "Age",
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your age';
        }
        int? age = int.tryParse(value);
        if (age == null || age <= 0) {
          return 'Please enter a valid age';
        }
        if (age < 18 || age > 60) {
          return 'Age must be between 18 and 60';
        }
        return null;
      },
    ),
  );
}

Widget mobileTextField() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: TextFormField(
      controller: mobileController,
      textAlign: TextAlign.center,
      decoration: InputDecoration(
        hintText: "Mobile",
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        filled: true,
        fillColor: Colors.white,
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your mobile number';
        }
        // Regular expression to validate Pakistani mobile numbers starting with 030 to 034, and 0355
        final regex = RegExp(r'^(03[0-4]\d{8}|0355\d{7})$');
        if (value.length != 11 || !regex.hasMatch(value)) {
          return 'Please enter a valid 11-digit Pakistani mobile number starting with 030 to 034, or 0355';
        }
        return null;
      },
      keyboardType: TextInputType.phone,
      maxLength: 11,
    ),
  );
}
  Widget cityDropDown() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: DropdownButtonFormField<String>(
        value: _selectedCity,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          labelText: 'City',
          contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          filled: true,
          fillColor: Colors.white,
        ),
        items: <String>
        ['Abbottabad', 'Abdul Hakim', 'Ahmadpur East', 'Attock', 'Bagh', 'Bahawalnagar', 'Bahawalpur',
          'Bannu', 'Bela', 'Bellampalli', 'Bhera', 'Burewala', 'Charsadda', 'Chak Azam Sahu', 'Chaklala', 'Chakwal',
          'Chaman', 'Charsadda', 'Chiniot', 'Chishtian', 'Chunian', 'Dadu', 'Daska', 'Dera Ghazi Khan',
          'Dera Ismail Khan', 'Dera Murad Jamali', 'Dhadar', 'Dharki', 'Dinga', 'Faisalabad', 'Farooqabad',
          'Fatehpur', 'Gharo', 'Ghotki', 'Gojra', 'Gujar Khan', 'Gujranwala', 'Gujrat', 'Gwadar', 'Hafizabad',
          'Hangu', 'Haripur', 'Hassan Abdal', 'Haveli Lakha', 'Havelian', 'Hujra Shah Muqim', 'Hyderabad',
          'Islamabad', 'Jacobabad', 'Jahanian Shah', 'Jalandhar', 'Jalalpur Jattan', 'Jampur', 'Jand', 'Jaranwala',
          'Jhang', 'Jhelum', 'Jhenaidah', 'Jodhpur', 'Kabirwala', 'Kahna', 'Kala Shah Kaku', 'Kalur Kot', 'Kamalia',
          'Kamoke', 'Kamra', 'Karachi', 'Karak', 'Kasur', 'Khanewal', 'Khangah Dogran', 'Khanpur', 'Kharian',
          'Khewra', 'Khuzdar', 'Kohat', 'Kohror Pakka', 'Kot Abdul Malik', 'Kot Addu', 'Kotri','Lahore', 'Lala Musa',
          'Larkana', 'Layyah', 'Liaqatabad', 'Lodhran', 'Loralai', 'Mailsi', 'Mandi', 'Mandi Bahauddin', 'Mastung',
          'Matli', 'Matiari', 'Mehar', 'Mehrabpur', 'Mian Channun', 'Mianwali', 'Minchinabad', 'Mirpur',
          'Mirpur Khas', 'Mirpur Sakro', 'Mithi', 'Multan', 'Muzaffargarh', 'Muzaffarabad', 'Nankana Sahib',
          'Narowal', 'Naudero', 'Nawabshah', 'Nowshera', 'Okara', 'Paharpur', 'Pad Idan', 'Padri', 'Pakpattan',
          'Pano Aqil', 'Pattoki', 'Peshawar', 'Pind Dadan Khan', 'Pishin', 'Quetta', 'Rahim Yar Khan', 'Rajanpur',
          'Raja Jang', 'Ranipur', 'Ratodero', 'Rawalpindi', 'Renala Khurd', 'Risalpur', 'Rojhan', 'Sadiqabad',
          'Sahiwal', 'Sakrand', 'Samaro', 'Sargodha', 'Sekondi-Takoradi', 'Sehwan Sharif', 'Shahdadkot', 'Shahdadpur',
          'Shahkot', 'Shahpur', 'Shahpur Chakar', 'Shahpur Saddar', 'Shahr Sultan', 'Sheikhupura', 'Shikarpur',
          'Shujaabad', 'Sialkot', 'Sibi', 'Sillanwali', 'Sodhra', 'Sobhodero', 'Sukkur', 'Surkhpur', 'Swabi',
          'Talagang', 'Talamba', 'Talhar', 'Taluka', 'Talwara', 'Talwara Mughlan', 'Talwara Jheel', 'Tangi',
          'Tando Adam', 'Tando Allahyar', 'Tando Ghulam Ali', 'Tando Jam', 'Tando Mittha Khan', 'Tando Muhammad Khan',
          'Tandlianwala', 'Tank', 'Tarbela', 'Tarakai', 'Tatlay Wali', 'Taxila', 'Thall', 'Tharu Shah', 'Thatta',
          'Thul', 'Timargara', 'Toba Tek Singh', 'Topi', 'Trandoshan', 'Turbat', 'Usta Muhammad', 'Uthal',
          'Utmam Khan', 'Vehari', 'Wah Cantonment', 'Wazirabad', 'Yazman', 'Zafarwal', 'Zahir Pir'
        ].map<DropdownMenuItem<String>>((String value)  {
          return DropdownMenuItem<String>(
            value: value,
            child: Center(child: Text(value)),
          );
        }).toList(),
        onChanged: (String? value) {
          setState(() {
            _selectedCity = value;
          });
        },
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please select your city';
          }
          return null;
        },
      ),
    );
  }

  Widget bloodGroupDropDown() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: DropdownButtonFormField<String>(
        value: _selectedBloodGroup,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          labelText: 'Blood Group',
          contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          filled: true,
          fillColor: Colors.white,
        ),
        items: <String>['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
            .map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Center(child: Text(value)),
          );
        }).toList(),
        onChanged: (String? value) {
          setState(() {
            _selectedBloodGroup = value;
          });
        },
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please select your blood group';
          }
          return null;
        },
      ),
    );
  }

  Widget getButton(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      child: ElevatedButton(
        onPressed: registerUser,
        child: Text(
          'Register',
          style: TextStyle(color: Colors.black),
        ),
        style: ElevatedButton.styleFrom(
          minimumSize: Size(200, 50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
      ),
    );
  }
}

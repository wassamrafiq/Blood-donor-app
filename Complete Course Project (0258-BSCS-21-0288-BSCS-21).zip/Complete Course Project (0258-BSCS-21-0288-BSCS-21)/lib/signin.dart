import 'package:blood_donor_application/search.dart';
import 'package:blood_donor_application/splash.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'donorprofile.dart';
import 'signup.dart'; // Add this import to navigate to the signup screen

class Signin extends StatefulWidget {
  const Signin({Key? key}) : super(key: key);

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;

  Future<void> loginUser() async {
    setState(() {
      _isLoading = true;
    });

    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: usernameController.text.trim(),
        password: passwordController.text.trim(),
      );

      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('userId', userCredential.user!.uid);
      await prefs.setString('userEmail', usernameController.text.trim());
  
        await prefs.setBool("KEYLOGIN", true);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => DonorProfile()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        popup("No user found for that email.", 14);
      } else if (e.code == 'wrong-password') {
        popup("Wrong password provided.", 14);
      } else {
        popup("Error: ${e.message}", 14);
      }
    } catch (e) {
      popup("Error: ${e.toString()}", 14);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void popup(String txt, double size) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Color(0xFFE50914), // Netflix red
        content: Row(
          children: [
            Icon(
              Icons.warning,
              color: Colors.white,
            ),
            SizedBox(width: 8), // Add spacing between icon and text
            Text(
              txt,
              style: TextStyle(fontSize: size, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 250,
              child: Image.asset("images/blood_3.png", fit: BoxFit.fill),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(20)),
              ),
            ),
            Container(
              height:MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 235, 4, 4),
              ),
              
              child: Column(
                children: [
                  SizedBox(
                    height: 55,
                  ),
                  usernameTextField(),
                  SizedBox(
                    height: 15,
                  ),
                  passwordTextField(),
                  SizedBox(
                    height: 15,
                  ),
                  getButton(context),
                  SizedBox(
                    height: 70,
                  ),
                  previousButton(context),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget usernameTextField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 450),
      child: TextField(
        controller: usernameController,
        decoration: InputDecoration(
          hintText: "Email",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide(color: Colors.white, width: 2),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
    );
  }

  Widget passwordTextField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 450),
      child: TextField(
        controller: passwordController,
        obscureText: true,
        decoration: InputDecoration(
          hintText: "Password",
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide(color: Colors.white, width: 2),
          ),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
    );
  }

  Widget getButton(BuildContext context) {
    return ElevatedButton(
      onPressed: loginUser,
      child: Text("Sign in", style: TextStyle(fontWeight: FontWeight.bold)),
    );
  }

  Widget previousButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(9),
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Signup()),
              );
            },
            child: Text(
              "<- Previous",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 255, 255, 255),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

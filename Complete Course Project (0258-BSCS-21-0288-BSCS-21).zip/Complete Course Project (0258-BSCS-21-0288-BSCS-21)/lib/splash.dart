import 'dart:async';
import 'package:blood_donor_application/homepage.dart';
import 'package:blood_donor_application/search.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    startTimer();
  }

  startTimer() {
    var duration = Duration(seconds: 3);
    return Timer(duration, route);
  }

  route() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isLoggedIn = prefs.getBool('KEYLOGIN') ?? false;
    if (isLoggedIn) {
      Navigator.of(context).pushReplacementNamed('/donorprofile');
    } else {
      Navigator.of(context).pushReplacementNamed('/homepage');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [ 
            Image.asset("images/blood_2.png", height: 200,width: 1500),
            const Text("Blood Donor Registration Application", 
              style: TextStyle(
                fontSize: 20, fontStyle: FontStyle.normal, fontWeight: FontWeight.bold
              )
            ),
          ],
        )
        
      ),
    );
  }

 
}
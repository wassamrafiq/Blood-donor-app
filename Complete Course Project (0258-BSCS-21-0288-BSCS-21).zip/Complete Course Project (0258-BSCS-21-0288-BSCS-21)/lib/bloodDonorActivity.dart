import 'dart:convert';

class BloodDonor {
  String name = "";
  int age = 0;
  String mobile = "";
  String city = "";
  String bloodGroup = "";
  String email = "";

  BloodDonor(this.name, this.age, this.mobile, this.city, this.bloodGroup,this.email);

  String toJsonString() {
    var dataMap = {
      "name": name,
      "age": age,
      "mobile": mobile,
      "city": city,
      "bloodGroup": bloodGroup,
      "email":email,
    };
    String jsonString = json.encode(dataMap);
    return jsonString;
  }

  Map<String, dynamic> toJsonMap() {
    var dataMap = {
      "name": name,
      "age": age,
      "mobile": mobile,
      "city": city,
      "bloodGroup": bloodGroup,
      "email":email,
    };
    return dataMap;
  }

  BloodDonor.fromJsonString(String jsonString) {
    var dataMap = json.decode(jsonString);

    name = dataMap["name"] ?? "";
    age = dataMap["age"] ?? 0;
    mobile = dataMap["mobile"] ?? "";
    city = dataMap["city"] ?? "";
    bloodGroup = dataMap["bloodGroup"] ?? "";
    email=dataMap["email"] ?? "";
  }

  BloodDonor.fromMap(Map<String, dynamic> dataMap) {
    name = dataMap["name"] ?? "";
    age = dataMap["age"] ?? 0;
    mobile = dataMap["mobile"] ?? "";
    city = dataMap["city"] ?? "";
    bloodGroup = dataMap["bloodGroup"] ?? "";
     email=dataMap["email"] ?? "";
  }
}

import 'package:flutter/material.dart';
import 'package:blood_donor_application/sidedrawer.dart';
import 'firestorehelper.dart';
import 'bloodDonorActivity.dart';

class Search extends StatefulWidget {
  const Search({Key? key}) : super(key: key);

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  List<BloodDonor> donorList = [];
  List<BloodDonor> filteredDonorList = [];
  String? _selectedBloodType;
  String? _selectedCity;

  @override
  void initState() {
    super.initState();
    getAllDonors();
  }

  void getAllDonors() async {
    try {
      FirestoreHelper firestoreHelper = await FirestoreHelper.getInstance();
      List<BloodDonor> donors = await firestoreHelper.getAllDonors();
      setState(() {
        donorList = donors;
        filteredDonorList = donors;
      });
    } catch (e) {
      print("Error getting donors: $e");
    }
  }

  void filterDonors() {
    setState(() {
      filteredDonorList = donorList.where((donor) {
        final matchesBloodType = _selectedBloodType == null || donor.bloodGroup.toLowerCase() == _selectedBloodType!.toLowerCase();
        final matchesCity = _selectedCity == null || donor.city.toLowerCase() == _selectedCity!.toLowerCase();
        return matchesBloodType && matchesCity;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Donors'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 220,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: Image.asset("images/blood_2.png"),
              ),
            ),
            SizedBox(height: 10),
            Text(
              "List of Donors",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.amber,
                fontSize: 20,
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: DropdownButtonFormField<String>(
                value: _selectedBloodType,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  labelText: 'Blood Type',
                ),
                items: <String>[
                  'O+', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O-'
                ].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _selectedBloodType = value;
                  });
                  filterDonors();
                },
              ),
            ),
            SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: DropdownButtonFormField<String>(
                value: _selectedCity,
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  labelText: 'City',
                ),
                items: donorList
                    .map((donor) => donor.city)
                    .toSet()
                    .map<DropdownMenuItem<String>>((String city) {
                  return DropdownMenuItem<String>(
                    value: city,
                    child: Text(city),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    _selectedCity = value;
                  });
                  filterDonors();
                },
              ),
            ),
            SizedBox(height: 10),
            ListView.builder(
              shrinkWrap: true,
              itemCount: filteredDonorList.length,
              itemBuilder: (BuildContext context, int index) {
                return ListTile(
                  title: Text(filteredDonorList[index].name),
                  subtitle: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(filteredDonorList[index].city),
                      Text(filteredDonorList[index].mobile),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
      // drawer: SideDrawer(),
    );
  }
}

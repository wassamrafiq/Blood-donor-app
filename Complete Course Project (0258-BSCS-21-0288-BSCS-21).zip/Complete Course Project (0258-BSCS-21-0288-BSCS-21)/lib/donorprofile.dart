import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:blood_donor_application/sidedrawer.dart';
import 'firestorehelper.dart';
import 'bloodDonorActivity.dart';

class DonorProfile extends StatefulWidget {
  const DonorProfile({Key? key}) : super(key: key);

  @override
  State<DonorProfile> createState() => _DonorProfileState();
}

class _DonorProfileState extends State<DonorProfile> {
  final _formKey = GlobalKey<FormState>();
  late BloodDonor donor;
  bool isLoading = true;

  Color red = Color(0xFFE50914);
  Color golden = Color(0xFFE2A808);
  Color grey = Color(0xFF525252);
  Color grey2 = Color(0xFF949494);
  Color black = Color(0xFF100C10);
  Color orange = Color(0xFFff5c30);

  TextEditingController nameController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController bloodGroupController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadDonorData();
  }

  Future<void> _loadDonorData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userEmail = prefs.getString('userEmail');
    FirestoreHelper firestoreHelper = await FirestoreHelper.getInstance();
    List<BloodDonor> donors = await firestoreHelper.getAllDonors();
    donor = donors.firstWhere((d) => d.email == userEmail);

    setState(() {
      nameController.text = donor.name;
      ageController.text = donor.age.toString();
      mobileController.text = donor.mobile;
      cityController.text = donor.city;
      bloodGroupController.text = donor.bloodGroup;
      isLoading = false;
    });
  }

  Future<void> _updateDonorData() async {
    if (_formKey.currentState!.validate()) {
      FirestoreHelper firestoreHelper = await FirestoreHelper.getInstance();
      await firestoreHelper.updateBloodDonor(donor.name, {
        'name': nameController.text,
        'age': int.parse(ageController.text),
        'mobile': mobileController.text,
        'city': cityController.text,
        'bloodGroup': bloodGroupController.text,
      });

      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('userName', nameController.text);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Profile updated successfully!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Donor Profile'),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.redAccent,
                          child: Icon(Icons.person, size: 50, color: Colors.white),
                        ),
                      ),
                      SizedBox(height: 20),
                      _buildTextField(nameController, 'Name', Icons.person),
                      SizedBox(height: 10),
                      _buildTextField(ageController, 'Age', Icons.cake, isNumber: true),
                      SizedBox(height: 10),
                      _buildTextField(mobileController, 'Mobile', Icons.phone, isPhone: true),
                      SizedBox(height: 10),
                      _buildTextField(cityController, 'City', Icons.location_city),
                      SizedBox(height: 10),
                      _buildTextField(bloodGroupController, 'Blood Group', Icons.bloodtype),
                      SizedBox(height: 20),
                      Center(
                        child: ElevatedButton(
                          onPressed: _updateDonorData,
                          child: Text(
                            'Save Changes',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
      drawer: SideDrawer(),
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    String labelText,
    IconData icon, {
    bool isNumber = false,
    bool isPhone = false,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        prefixIcon: Icon(icon),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        filled: true,
        fillColor: Colors.grey[200],
      ),
      keyboardType: isNumber
          ? TextInputType.number
          : (isPhone ? TextInputType.phone : TextInputType.text),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your $labelText';
        }
        if (isNumber && int.tryParse(value) == null) {
          return 'Please enter a valid $labelText';
        }
        return null;
      },
    );
  }
}
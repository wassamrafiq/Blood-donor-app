import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'bloodDonorActivity.dart';
import 'firebase_options.dart'; // Import your Firebase options

class FirestoreHelper {
  final FirebaseFirestore _firestoreInstance = FirebaseFirestore.instance;

  FirestoreHelper._();

  static final FirestoreHelper _singleObj = FirestoreHelper._();
  static bool _isFirstTime = true;

  Future<void> updateBloodDonor(String name, Map<String, dynamic> updatedData) async {
    await _firestoreInstance.collection("donors").doc(name).update(updatedData);
  }


  static Future<FirestoreHelper> getInstance() async {
    if (_isFirstTime) {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
      _isFirstTime = false;
    }
    return _singleObj;
  }

  Future<int> getExistingCounter() async {
    var docRef = _firestoreInstance.collection("counterCollection").doc("counterDoc");

    var doc = await docRef.get();

    if (doc.exists) {
      return doc.data()?['value'] ?? 1;
    }
    await _firestoreInstance.collection("counterCollection").doc("counterDoc").set({"value": 1});

    return 1;
  }

  Future<void> saveBloodDonor(BloodDonor donor) async {
    await _firestoreInstance.collection("donors").doc(donor.name).set(donor.toJsonMap());

    int existingValue = await getExistingCounter();
    await _firestoreInstance.collection("counterCollection").doc("counterDoc").set({"value": existingValue + 1});
  }

  Future<void> removeExistingDonor(String name) async {
    await _firestoreInstance.collection("donors").doc(name).delete();
  }

  Future<List<BloodDonor>> getAllDonors() async {
    List<BloodDonor> donorList = [];

    var snapshot = await _firestoreInstance.collection("donors").get();

    for (var doc in snapshot.docs) {
      donorList.add(BloodDonor.fromMap(doc.data()));
    }
    return donorList;
  }
}
